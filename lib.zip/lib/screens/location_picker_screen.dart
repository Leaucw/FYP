import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class LocationResult {
	final double latitude;
	final double longitude;
	final String? name;
	LocationResult({required this.latitude, required this.longitude, this.name});
}

class LocationPickerScreen extends StatefulWidget {
	final double? initialLat;
	final double? initialLng;
	final String? initialName;
	const LocationPickerScreen({super.key, this.initialLat, this.initialLng, this.initialName});

	@override
	State<LocationPickerScreen> createState() => _LocationPickerScreenState();
}

class _LocationPickerScreenState extends State<LocationPickerScreen> {
	LatLng? _selected;
	final _nameCtrl = TextEditingController();
	final _searchCtrl = TextEditingController();
	bool _searching = false;

	@override
	void initState() {
		super.initState();
		if (widget.initialLat != null && widget.initialLng != null) {
			_selected = LatLng(widget.initialLat!, widget.initialLng!);
		}
		_nameCtrl.text = widget.initialName ?? '';
	}

	@override
	void dispose() {
		_nameCtrl.dispose();
		_searchCtrl.dispose();
		super.dispose();
	}

	Future<void> _searchPlace() async {
		final q = _searchCtrl.text.trim();
		if (q.isEmpty) return;
		setState(() => _searching = true);
		try {
			final uri = Uri.parse('https://nominatim.openstreetmap.org/search?q=$q&format=json&limit=1');
			final res = await http.get(uri, headers: {'User-Agent': 'fyp/1.0'});
			if (res.statusCode == 200) {
				final List data = json.decode(res.body) as List;
				if (data.isNotEmpty) {
					final item = data.first as Map<String, dynamic>;
					final lat = double.tryParse(item['lat']?.toString() ?? '');
					final lon = double.tryParse(item['lon']?.toString() ?? '');
					if (lat != null && lon != null) {
						setState(() {
							_selected = LatLng(lat, lon);
							_nameCtrl.text = item['display_name']?.toString() ?? _nameCtrl.text;
						});
					}
				}
			}
		} catch (_) {}
		setState(() => _searching = false);
	}

	Future<void> _reverseGeocode(LatLng point) async {
		try {
			final uri = Uri.parse('https://nominatim.openstreetmap.org/reverse?lat=${point.latitude}&lon=${point.longitude}&format=json');
			final res = await http.get(uri, headers: {'User-Agent': 'fyp/1.0'});
			if (res.statusCode == 200) {
				final data = json.decode(res.body) as Map<String, dynamic>;
				final display = data['display_name']?.toString();
				if (display != null && display.isNotEmpty) {
					setState(() => _nameCtrl.text = display);
				}
			}
		} catch (_) {}
	}

	@override
	Widget build(BuildContext context) {
		final mapCenter = _selected ?? const LatLng(3.1390, 101.6869); // default Kuala Lumpur
		return Scaffold(
			appBar: AppBar(
				title: const Text('Select Location'),
			),
			body: Column(
				children: [
					Expanded(
						child: FlutterMap(
							options: MapOptions(
								initialCenter: mapCenter,
								initialZoom: _selected != null ? 13 : 5,
								onTap: (tapPosition, point) async {
									setState(() => _selected = point);
									await _reverseGeocode(point);
								},
							),
							children: [
								TileLayer(
									urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
									userAgentPackageName: 'com.example.fyp',
								),
								if (_selected != null)
									MarkerLayer(
										markers: [
											Marker(
												point: _selected!,
												width: 40,
												height: 40,
												child: const Icon(Icons.location_on, color: Colors.redAccent, size: 36),
											),
										],
									),
							],
						),
					),
					Padding(
						padding: const EdgeInsets.all(16.0),
						child: Column(
							crossAxisAlignment: CrossAxisAlignment.start,
							children: [
								Row(
									children: [
										Expanded(
											child: TextField(
												controller: _searchCtrl,
												decoration: const InputDecoration(
													labelText: 'Search place',
													border: OutlineInputBorder(),
												),
												onSubmitted: (_) => _searchPlace(),
											),
										),
										const SizedBox(width: 8),
										IconButton(
											onPressed: _searching ? null : _searchPlace,
											icon: _searching ? const SizedBox(height: 20, width: 20, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.search),
										),
									],
								),
								const SizedBox(height: 12),
								if (_selected != null)
									Text('Lat: ${_selected!.latitude.toStringAsFixed(4)}, Lng: ${_selected!.longitude.toStringAsFixed(4)}'),
								const SizedBox(height: 8),
								TextField(
									controller: _nameCtrl,
									decoration: const InputDecoration(
										labelText: 'Location name (optional)',
										border: OutlineInputBorder(),
									),
								),
								const SizedBox(height: 12),
								SizedBox(
									width: double.infinity,
									child: ElevatedButton(
										onPressed: _selected == null
												? null
												: () {
											final result = LocationResult(
												latitude: _selected!.latitude,
												longitude: _selected!.longitude,
												name: _nameCtrl.text.trim().isEmpty ? null : _nameCtrl.text.trim(),
											);
											Navigator.pop(context, result);
										},
										child: const Text('Use this location'),
									),
								),
							],
						),
					),
				],
			),
		);
	}
}


