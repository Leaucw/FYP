import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/goal.dart';
import '../services/goal_service.dart';
import '../theme/app_colors.dart';
import 'goal_upsert_screen.dart';
import 'goal_view_screen.dart';

class GoalsListScreen extends StatelessWidget {
	final _auth = FirebaseAuth.instance;
	final _service = GoalService(db: FirebaseFirestore.instance);

	GoalsListScreen({super.key});

	@override
	Widget build(BuildContext context) {
		final user = _auth.currentUser;
		if (user == null) {
			return const Scaffold(
				body: Center(child: Text('Please sign in to view goals')),
			);
		}
		return Scaffold(
			appBar: AppBar(
				title: const Text('Goals'),
				backgroundColor: AppColors.primary,
				foregroundColor: Colors.white,
				actions: [
					IconButton(
						icon: const Icon(Icons.archive),
						onPressed: () {
							Navigator.pushNamed(context, '/archived');
						},
					)
				],
			),
			body: StreamBuilder<List<Goal>>(
				stream: _service.streamGoals(user.uid),
				builder: (context, snapshot) {
					if (snapshot.connectionState == ConnectionState.waiting) {
						return const Center(child: CircularProgressIndicator());
					}
					final goals = snapshot.data ?? const [];
					if (goals.isEmpty) {
						return const Center(child: Text('No goals yet. Tap + to add.'));
					}
					return ListView.separated(
						padding: const EdgeInsets.all(12),
						itemCount: goals.length,
						separatorBuilder: (_, __) => const SizedBox(height: 8),
						itemBuilder: (context, index) {
							final g = goals[index];
							final completedSub = g.subGoals.where((s) => s.completed).length;
							final now = DateTime.now();
							final due = g.endDate;
							String? dueLabel;
							Color? dueColor;
							if (due != null && g.status != GoalStatus.completed) {
								final days = due.difference(now).inDays;
								if (days < 0) {
									dueLabel = 'Overdue ${-days}d';
									dueColor = Colors.redAccent;
								} else if (days <= 3) {
									dueLabel = 'Due in ${days}d';
									dueColor = Colors.orangeAccent;
								}
							}
							return Dismissible(
								key: ValueKey(g.id),
								background: Container(
									color: Colors.redAccent,
									alignment: Alignment.centerRight,
									padding: const EdgeInsets.symmetric(horizontal: 20),
									child: const Icon(Icons.delete, color: Colors.white),
								),
								direction: DismissDirection.endToStart,
								confirmDismiss: (_) async {
									return await showDialog<bool>(
										context: context,
										builder: (_) => AlertDialog(
											title: const Text('Delete goal?'),
											content: Text('Are you sure you want to delete "${g.title}"?'),
											actions: [
												TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')),
												TextButton(onPressed: () => Navigator.pop(context, true), child: const Text('Delete')),
											],
										),
									) ?? false;
								},
								onDismissed: (_) async {
									await _service.deleteGoal(user.uid, g.id);
								},
								child: ListTile(
									onTap: () {
										Navigator.push(context, MaterialPageRoute(
											builder: (_) => GoalViewScreen(goalId: g.id, userId: user.uid),
										));
									},
									title: Text(g.title, style: const TextStyle(fontWeight: FontWeight.w600)),
									subtitle: Column(
										crossAxisAlignment: CrossAxisAlignment.start,
										children: [
											Text(g.category, style: const TextStyle(fontWeight: FontWeight.w500)),
											const SizedBox(height: 2),
											Text('Status: ${g.status.name}'),
											const SizedBox(height: 4),
											if (g.description.isNotEmpty) Text(g.description, maxLines: 1, overflow: TextOverflow.ellipsis),
											if (g.subGoals.isNotEmpty) ...[
												const SizedBox(height: 6),
												LinearProgressIndicator(
													value: completedSub / g.subGoals.length,
													backgroundColor: Colors.grey.shade300,
													color: completedSub == g.subGoals.length ? Colors.green : AppColors.primary,
													minHeight: 6,
												),
											],
											const SizedBox(height: 4),
											if (g.subGoals.isNotEmpty) Text('${completedSub}/${g.subGoals.length} sub-goals'),
										],
									),
									trailing: Column(
										mainAxisAlignment: MainAxisAlignment.center,
										children: [
											if (dueLabel != null) Container(
												padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
												decoration: BoxDecoration(color: dueColor?.withOpacity(0.15), borderRadius: BorderRadius.circular(8)),
												child: Text(dueLabel, style: TextStyle(color: dueColor, fontSize: 12)),
											),
											IconButton(
												icon: const Icon(Icons.edit),
												onPressed: () {
													Navigator.push(context, MaterialPageRoute(
														builder: (_) => GoalUpsertScreen.edit(existing: g),
													));
												},
											),
										],
									),
								),
							);
						},
					);
				},
			),
			floatingActionButton: FloatingActionButton(
				backgroundColor: AppColors.highlight,
				onPressed: () {
					Navigator.push(context, MaterialPageRoute(
						builder: (_) => GoalUpsertScreen.create(),
					));
				},
				child: const Icon(Icons.add, color: Colors.white),
			),
		);
	}
}


