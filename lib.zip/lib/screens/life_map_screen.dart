import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import '../models/map_pin.dart';
import '../models/goal.dart';
import '../models/achievement.dart';
import '../services/map_pin_service.dart';
import '../theme/app_colors.dart';
import '../services/goal_service.dart';
import '../services/achievement_service.dart';

class LifeMapScreen extends StatefulWidget {
	LifeMapScreen({super.key});

	@override
	State<LifeMapScreen> createState() => _LifeMapScreenState();
}

class _LifeMapScreenState extends State<LifeMapScreen> {
	final _auth = FirebaseAuth.instance;
	final _service = MapPinService(db: FirebaseFirestore.instance);
	final _goalService = GoalService(db: FirebaseFirestore.instance);
	final _achievementService = AchievementService(db: FirebaseFirestore.instance);
	final MapController _mapController = MapController();
	bool _showSidebar = true;

	Future<void> _playMemories(String userId) async {
		final goalsSnap = await _goalService.streamGoals(userId).first;
		final achievementsSnap = await _achievementService.getAchievements().first;

		final items = <_MapItem>[
			...goalsSnap
					.where((g) => g.status == GoalStatus.completed && g.latitude != null && g.longitude != null)
					.map((g) => _MapItem.goal(
				title: g.title,
				description: g.description,
				category: g.category,
				date: g.completedAt ?? g.endDate ?? g.createdAt,
				latitude: g.latitude!,
				longitude: g.longitude!,
				locationName: g.locationName,
			)),
			...achievementsSnap
					.where((a) => a.latitude != null && a.longitude != null)
					.map((a) => _MapItem.achievement(
				title: a.title,
				description: a.description,
				category: a.category,
				date: a.date,
				latitude: a.latitude!,
				longitude: a.longitude!,
				locationName: a.locationName,
			)),
		]
			..sort((a, b) => a.date.compareTo(b.date));

		for (final item in items) {
			if (!mounted) break;
			_mapController.move(LatLng(item.latitude, item.longitude), 9.5);
			await Future.delayed(const Duration(milliseconds: 800));
			_mapController.move(LatLng(item.latitude, item.longitude), 12.0);
			await Future.delayed(const Duration(milliseconds: 800));
		}
	}

	@override
	Widget build(BuildContext context) {
		final user = _auth.currentUser;
		if (user == null) return const Scaffold(body: Center(child: Text('Please sign in')));
		return Scaffold(
			appBar: AppBar(
				title: const Text('Life Map'),
				backgroundColor: AppColors.primary,
				foregroundColor: Colors.white,
				actions: [
					IconButton(
						tooltip: 'Memories autoplay',
						icon: const Icon(Icons.play_circle_fill),
						onPressed: () async {
							if (!mounted) return;
							await _playMemories(user.uid);
						},
					),
					IconButton(
						tooltip: _showSidebar ? 'Hide list' : 'Show list',
						onPressed: () => setState(() => _showSidebar = !_showSidebar),
						icon: Icon(_showSidebar ? Icons.view_sidebar : Icons.view_list),
					),
				],
			),
			body: StreamBuilder<List<MapPin>>(
				stream: _service.stream(user.uid),
				builder: (context, pinsSnap) {
					if (!pinsSnap.hasData) return const Center(child: CircularProgressIndicator());
					final pins = pinsSnap.data!;
					return StreamBuilder<List<Goal>>(
						stream: _goalService.streamGoals(user.uid),
						builder: (context, goalsSnap) {
							if (!goalsSnap.hasData) return const Center(child: CircularProgressIndicator());
							return StreamBuilder<List<Achievement>>(
								stream: _achievementService.getAchievements(),
								builder: (context, achievementsSnap) {
									if (!achievementsSnap.hasData) return const Center(child: CircularProgressIndicator());

									final completedGoals = goalsSnap.data!
											.where((g) => g.status == GoalStatus.completed && g.latitude != null && g.longitude != null)
											.toList();
									final achievements = achievementsSnap.data!
											.where((a) => a.latitude != null && a.longitude != null)
											.toList();

									final combined = <_MapItem>[
										...completedGoals.map((g) => _MapItem.goal(
											title: g.title,
											description: g.description,
											category: g.category,
											date: g.completedAt ?? g.endDate ?? g.createdAt,
											latitude: g.latitude!,
											longitude: g.longitude!,
											locationName: g.locationName,
										)),
										...achievements.map((a) => _MapItem.achievement(
											title: a.title,
											description: a.description,
											category: a.category,
											date: a.date,
											latitude: a.latitude!,
											longitude: a.longitude!,
											locationName: a.locationName,
										)),
									]
										..sort((a, b) => b.date.compareTo(a.date));

									final markers = <Marker>[
										...pins.map((p) => Marker(
											point: LatLng(p.latitude, p.longitude),
											width: 40,
											height: 40,
											child: IconButton(
												icon: const Icon(Icons.location_on, color: Colors.redAccent, size: 32),
												onPressed: () async {
													Goal? goal;
													if (p.relatedGoalId != null) {
														final doc = await FirebaseFirestore.instance
																.collection('users').doc(user.uid)
																.collection('goals').doc(p.relatedGoalId).get();
														if (doc.exists) goal = Goal.fromDoc(doc as DocumentSnapshot<Map<String, dynamic>>);
													}
													showDialog(
														context: context,
														builder: (_) => AlertDialog(
															title: Text(p.title),
															content: SingleChildScrollView(
																child: Column(
																	mainAxisSize: MainAxisSize.min,
																	crossAxisAlignment: CrossAxisAlignment.start,
																	children: [
																		if (p.description != null) ...[Text(p.description!), const SizedBox(height: 8)],
																		if (p.locationName != null) Text('Location: ${p.locationName!}'),
																		Text('Coordinates: ${p.latitude.toStringAsFixed(3)}, ${p.longitude.toStringAsFixed(3)}'),
																		if (goal != null) ...[
																			const SizedBox(height: 8),
																			Text('Linked goal: ${goal.title}'),
																			Text('Status: ${goal.status.name}'),
																		],
																	],
																),
															),
															actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Close'))],
														),
													);
												},
											),
										)),
										...combined.map((item) => Marker(
											point: LatLng(item.latitude, item.longitude),
											width: 40,
											height: 40,
											child: IconButton(
												icon: Icon(item.isAchievement ? Icons.emoji_events : Icons.flag,
														color: item.isAchievement ? Colors.amber : Colors.blueAccent, size: 30),
												onPressed: () {
													showDialog(
														context: context,
														builder: (_) => AlertDialog(
															title: Text(item.title),
															content: Column(
																mainAxisSize: MainAxisSize.min,
																crossAxisAlignment: CrossAxisAlignment.start,
																children: [
																	Text('Date: ${item.date.toLocal().toIso8601String().split('T').first}'),
																	Text('Category: ${item.category}'),
																	if (item.locationName != null) Text('Location: ${item.locationName!}'),
																	if (item.description.isNotEmpty) ...[const SizedBox(height: 8), Text(item.description)],
																],
															),
															actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Close'))],
														),
													);
												},
											),
										)),
									];

									return LayoutBuilder(
										builder: (context, constraints) {
											final sidebarWidth = constraints.maxWidth >= 900 ? 320.0 : 280.0;
											return Row(
												children: [
													Expanded(
														child: FlutterMap(
															mapController: _mapController,
															options: const MapOptions(initialCenter: LatLng(0, 0), initialZoom: 1.5),
															children: [
																TileLayer(urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png', userAgentPackageName: 'com.example.fyp'),
																MarkerLayer(markers: markers),
															],
														),
													),
													if (_showSidebar)
														Container(
															width: sidebarWidth,
															color: Colors.white,
															child: Column(
																crossAxisAlignment: CrossAxisAlignment.start,
																children: [
																	const Padding(
																		padding: EdgeInsets.all(12.0),
																		child: Text('Completed Goals & Achievements', style: TextStyle(fontWeight: FontWeight.w700)),
																	),
																	const Divider(height: 1),
																	Expanded(
																		child: ListView.builder(
																			itemCount: combined.length,
																			itemBuilder: (context, index) {
																				final item = combined[index];
																				final dateText = item.date.toLocal().toIso8601String().split('T').first;
																				return ListTile(
																					leading: Icon(item.isAchievement ? Icons.emoji_events : Icons.flag,
																							color: item.isAchievement ? Colors.amber : Colors.blueAccent),
																					dense: true,
																					title: Text(item.title, maxLines: 1, overflow: TextOverflow.ellipsis),
																					subtitle: Text('${item.locationName ?? 'No location'} • $dateText'),
																					trailing: const Icon(Icons.chevron_right),
																					onTap: () {
																						_mapController.move(LatLng(item.latitude, item.longitude), 12.0);
																					},
																				);
																			},
																		),
																	),
																],
															),
														),
												],
											);
										},
									);
								},
							);
						},
					);
				},
			),
		);
	}
}

class _MapItem {
	final String title;
	final String description;
	final String category;
	final DateTime date;
	final double latitude;
	final double longitude;
	final String? locationName;
	final bool isAchievement;

	_MapItem.goal({
		required this.title,
		required this.description,
		required this.category,
		required this.date,
		required this.latitude,
		required this.longitude,
		required this.locationName,
	}) : isAchievement = false;

	_MapItem.achievement({
		required this.title,
		required this.description,
		required this.category,
		required this.date,
		required this.latitude,
		required this.longitude,
		required this.locationName,
	}) : isAchievement = true;
}


