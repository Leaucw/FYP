import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:uuid/uuid.dart';
import '../models/goal.dart';
import '../models/achievement.dart';
import '../services/goal_service.dart';
import '../services/achievement_service.dart';
import '../theme/app_colors.dart';

class GoalViewScreen extends StatefulWidget {
	final String goalId;
	final String userId;
	const GoalViewScreen({super.key, required this.goalId, required this.userId});

	@override
	State<GoalViewScreen> createState() => _GoalViewScreenState();
}

class _GoalViewScreenState extends State<GoalViewScreen> {
	final _goals = GoalService(db: FirebaseFirestore.instance);
	final _achievements = AchievementService(db: FirebaseFirestore.instance);
	Goal? _goal;
	bool _loading = true;

	@override
	void initState() {
		super.initState();
		_load();
	}

	Future<void> _load() async {
		setState(() => _loading = true);
		final doc = await FirebaseFirestore.instance
				.collection('users').doc(widget.userId)
				.collection('goals').doc(widget.goalId).get();
		if (!doc.exists) {
			if (mounted) Navigator.pop(context);
			return;
		}
		final goal = Goal.fromDoc(doc as DocumentSnapshot<Map<String, dynamic>>);
		if (goal.status != GoalStatus.completed && goal.endDate != null && DateTime.now().isAfter(goal.endDate!) && goal.status != GoalStatus.missed) {
			await _goals.updateGoal(widget.userId, goal.copyWith(status: GoalStatus.missed, updatedAt: DateTime.now()));
			if (mounted) {
				_goal = goal.copyWith(status: GoalStatus.missed);
				_loading = false;
			}
			return;
		}
		setState(() {
			_goal = goal;
			_loading = false;
		});
	}

	Future<void> _toggleSub(String id, bool value) async {
		if (_goal == null) return;
		final target = _goal!.subGoals.firstWhere((e) => e.id == id).copyWith(completed: value);
		await _goals.updateSubGoal(widget.userId, widget.goalId, target);
		final doc = await FirebaseFirestore.instance
				.collection('users').doc(widget.userId)
				.collection('goals').doc(widget.goalId).get();
		if (!doc.exists) {
			if (mounted) Navigator.pop(context);
			return;
		}
		final goal = Goal.fromDoc(doc as DocumentSnapshot<Map<String, dynamic>>);
		final allDone = goal.subGoals.isNotEmpty && goal.subGoals.every((s) => s.completed);
		if (allDone && goal.status != GoalStatus.completed) {
			await _goals.updateGoal(widget.userId, goal.copyWith(
				status: GoalStatus.completed,
				completedAt: DateTime.now(),
				updatedAt: DateTime.now(),
			));
		} else if (!allDone && goal.status == GoalStatus.completed) {
			final now = DateTime.now();
			final next = (goal.endDate != null && now.isAfter(goal.endDate!)) ? GoalStatus.missed : GoalStatus.inProgress;
			await _goals.updateGoal(widget.userId, goal.copyWith(
				status: next,
				completedAt: null,
				updatedAt: DateTime.now(),
			));
		}
		await _load();
	}

	Future<void> _addSub() async {
		final ctrl = TextEditingController();
		await showDialog(
			context: context,
			builder: (_) => AlertDialog(
				title: const Text('Add sub-goal'),
				content: TextField(controller: ctrl, decoration: const InputDecoration(hintText: 'Title')),
				actions: [
					TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
					TextButton(onPressed: () async {
						if (ctrl.text.trim().isEmpty) return;
						final sub = SubGoal(id: const Uuid().v4(), title: ctrl.text.trim(), completed: false, dueDate: null);
						await _goals.addSubGoal(widget.userId, widget.goalId, sub);
						if (mounted) Navigator.pop(context);
						await _load();
					}, child: const Text('Add')),
				],
			),
		);
	}

	Future<void> _markCompletedAsAchievement() async {
		if (_goal == null) return;
		final g = _goal!;
		final confirm = await showDialog<bool>(
			context: context,
			builder: (_) => AlertDialog(
				title: const Text('Convert to Achievement?'),
				content: const Text('This will move the goal into achievements and remove it from your goals list. Continue?'),
				actions: [
					TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')),
					TextButton(onPressed: () => Navigator.pop(context, true), child: const Text('Convert')),
				],
			),
		) ?? false;
		if (!confirm) return;
		final when = g.completedAt ?? g.endDate ?? DateTime.now();
		final now = DateTime.now();   // ⭐ MUST BE HERE
		final a = Achievement(
			id: '', // will be replaced by Firestore doc ID
			userId: g.userId,
			title: g.title,
			description: g.description,
			date: when,
			category: g.category,
			associatedPeople: g.associatedPeople,
			lifeStageId: null,
			locationName: g.locationName,
			latitude: g.latitude,
			longitude: g.longitude,
			sourceGoalId: g.id,
			createdAt: now,
			updatedAt: now,

			// NEW FIELDS
			points: 0,           // will be recalculated by the service
			photoBase64: null,   // goals don’t have photos, so default null
		);
		await _goals.deleteGoal(widget.userId, g.id);
		if (!mounted) return;
		ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Goal converted to achievement')));
		Navigator.pop(context);
	}

	void _markStatus(GoalStatus status) async {
		if (_goal == null) return;
		if (status != GoalStatus.completed && _goal!.status == GoalStatus.completed) {
			final now = DateTime.now();
			status = (_goal!.endDate != null && now.isAfter(_goal!.endDate!)) ? GoalStatus.missed : GoalStatus.inProgress;
		}
		await _goals.updateGoal(widget.userId, _goal!.copyWith(
			status: status,
			completedAt: status == GoalStatus.completed ? (_goal!.completedAt ?? DateTime.now()) : null,
			updatedAt: DateTime.now(),
		));
		await _load();
	}

	@override
	Widget build(BuildContext context) {
		return Scaffold(
			appBar: AppBar(
				title: const Text('Goal'),
				backgroundColor: AppColors.primary,
				foregroundColor: Colors.white,
				actions: [
					IconButton(onPressed: _addSub, icon: const Icon(Icons.playlist_add))
				],
			),
			body: _loading || _goal == null
					? const Center(child: CircularProgressIndicator())
					: Padding(
				padding: const EdgeInsets.all(16),
				child: Column(
					crossAxisAlignment: CrossAxisAlignment.start,
					children: [
						Text(_goal!.title, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w700)),
						const SizedBox(height: 6),
						if (_goal!.description.isNotEmpty) Text(_goal!.description),
						const SizedBox(height: 12),
						Wrap(
							spacing: 8,
							runSpacing: 8,
							children: [
								Chip(label: Text(_goal!.status.name)),
								Chip(label: Text(_goal!.category)),
								if (_goal!.locationName != null) Chip(label: Text(_goal!.locationName!)),
							],
						),
						const SizedBox(height: 8),
						if (_goal!.startDate != null || _goal!.endDate != null)
							Text(
								'${_goal!.startDate?.toIso8601String().split('T').first ?? 'No start'} → ${_goal!.endDate?.toIso8601String().split('T').first ?? 'No deadline'}',
								style: const TextStyle(color: AppColors.textSecondary),
							),
						if (_goal!.latitude != null && _goal!.longitude != null)
							Padding(
								padding: const EdgeInsets.only(top: 6.0),
								child: Text(
									'Location coordinates: ${_goal!.latitude!.toStringAsFixed(3)}, ${_goal!.longitude!.toStringAsFixed(3)} (visible on Life Map when completed)',
									style: const TextStyle(color: AppColors.textSecondary),
								),
							),
						const SizedBox(height: 12),
						Row(
							children: [
								ElevatedButton.icon(
									onPressed: () => _markStatus(GoalStatus.completed),
									icon: const Icon(Icons.check_circle_outline),
									label: const Text('Mark Completed'),
								),
								const SizedBox(width: 8),
								ElevatedButton.icon(
									onPressed: () => _markStatus(GoalStatus.inProgress),
									icon: const Icon(Icons.undo),
									label: const Text('Unmark'),
								),
							],
						),
						const SizedBox(height: 12),
						const Text('Sub-goals', style: TextStyle(fontWeight: FontWeight.w600)),
						const SizedBox(height: 8),
						Expanded(
							child: ListView.separated(
								itemCount: _goal!.subGoals.length,
								separatorBuilder: (_, __) => const Divider(height: 1),
								itemBuilder: (context, index) {
									final s = _goal!.subGoals[index];
									final prevCompleted = index == 0 ? true : _goal!.subGoals[index - 1].completed;
									return CheckboxListTile(
										title: Text(s.title),
										value: s.completed,
										onChanged: prevCompleted ? (v) => _toggleSub(s.id, v ?? false) : null,
										subtitle: prevCompleted ? null : const Text('Complete previous to unlock'),
									);
								},
							),
						),
						const SizedBox(height: 8),
						SizedBox(
							width: double.infinity,
							child: ElevatedButton.icon(
								onPressed: _goal!.status == GoalStatus.completed && !_goal!.convertedToAchievement
										? _markCompletedAsAchievement
										: null,
								icon: const Icon(Icons.emoji_events),
								label: const Text('Mark as Achievement'),
							),
						),
					],
				),
			),
		);
	}
}


