import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:intl/intl.dart';
import '../models/goal.dart';
import '../models/achievement.dart';
import '../services/goal_service.dart';
import '../services/achievement_service.dart';
import '../theme/app_colors.dart';

const _goalCategories = [
	'Health & Wellness',
	'Career & Finance',
	'Education & Learning',
	'Relationships & Community',
	'Personal Growth',
];

class AnalyticsDashboardScreen extends StatefulWidget {
	AnalyticsDashboardScreen({super.key});

	@override
	State<AnalyticsDashboardScreen> createState() => _AnalyticsDashboardScreenState();
}

class _AnalyticsDashboardScreenState extends State<AnalyticsDashboardScreen> {
	final _auth = FirebaseAuth.instance;
	final _goals = GoalService(db: FirebaseFirestore.instance);
	final _achievements = AchievementService(db: FirebaseFirestore.instance);

	String _mode = 'All Time';
	int? _selectedYear;
	int? _selectedQuarterYear;
	String _selectedQuarter = 'Q1';
	int? _selectedMonthYear;
	int _selectedMonth = DateTime.now().month;
	DateTimeRange? _customRange;

	void _setMode(String mode, List<int> years) {
		setState(() {
			_mode = mode;
			if (mode == 'Year') {
				_selectedYear = _selectedYear ?? (years.isNotEmpty ? years.first : DateTime.now().year);
			} else if (mode == 'Quarter') {
				_selectedQuarterYear = _selectedQuarterYear ?? (years.isNotEmpty ? years.first : DateTime.now().year);
				_selectedQuarter = 'Q1';
			} else if (mode == 'Month') {
				_selectedMonthYear = _selectedMonthYear ?? (years.isNotEmpty ? years.first : DateTime.now().year);
				_selectedMonth = DateTime.now().month;
			} else if (mode == 'Custom') {
				_customRange ??= DateTimeRange(
					start: DateTime.now().subtract(const Duration(days: 30)),
					end: DateTime.now(),
				);
			}
		});
	}

	DateTime? _rangeStart(List<Goal> goals, List<Achievement> achievements) {
		final dates = <DateTime>[
			...goals.map((g) => g.createdAt),
			...goals.where((g) => g.completedAt != null).map((g) => g.completedAt!),
			...achievements.map((a) => a.date),
		];
		if (dates.isEmpty) return DateTime.now();
		dates.sort();
		return dates.first;
	}

	DateTime? _rangeEnd(List<Goal> goals, List<Achievement> achievements) {
		final dates = <DateTime>[
			...goals.map((g) => g.createdAt),
			...goals.where((g) => g.completedAt != null).map((g) => g.completedAt!),
			...achievements.map((a) => a.date),
		];
		if (dates.isEmpty) return DateTime.now();
		dates.sort();
		return dates.last;
	}

	@override
	Widget build(BuildContext context) {
		final user = _auth.currentUser;
		if (user == null) return const Scaffold(body: Center(child: Text('Please sign in')));

		return Scaffold(
			appBar: AppBar(
				title: const Text('Dashboard'),
				backgroundColor: AppColors.primary,
				foregroundColor: Colors.white,
			),
			body: StreamBuilder<List<Goal>>(
				stream: _goals.streamGoals(user.uid),
				builder: (context, goalSnap) {
					if (!goalSnap.hasData) return const Center(child: CircularProgressIndicator());
					return StreamBuilder<List<Achievement>>(
						stream: _achievements.getAchievements(),
						builder: (context, achievementSnap) {
							if (!achievementSnap.hasData) return const Center(child: CircularProgressIndicator());

							final goals = goalSnap.data!;
							final achievements = achievementSnap.data!;

							final years = <int>{
								...goals.map((g) => g.createdAt.year),
								...goals.where((g) => g.completedAt != null).map((g) => g.completedAt!.year),
								...achievements.map((a) => a.date.year),
							}.toList()
								..sort((a, b) => b.compareTo(a));

							if (_mode == 'Year' && _selectedYear == null && years.isNotEmpty) {
								_selectedYear = years.first;
							}
							if (_mode == 'Quarter' && _selectedQuarterYear == null && years.isNotEmpty) {
								_selectedQuarterYear = years.first;
							}
							if (_mode == 'Month' && _selectedMonthYear == null && years.isNotEmpty) {
								_selectedMonthYear = years.first;
							}

							DateTime? start;
							DateTime? end;
							switch (_mode) {
								case 'All Time':
									start = null;
									end = null;
									break;
								case 'Year':
									final year = _selectedYear ?? DateTime.now().year;
									start = DateTime(year, 1, 1);
									end = DateTime(year, 12, 31, 23, 59, 59);
									break;
								case 'Quarter':
									final year = _selectedQuarterYear ?? DateTime.now().year;
									final quarterMap = {
										'Q1': const Tuple2(1, 3),
										'Q2': const Tuple2(4, 6),
										'Q3': const Tuple2(7, 9),
										'Q4': const Tuple2(10, 12),
									};
									final range = quarterMap[_selectedQuarter] ?? const Tuple2(1, 3);
									start = DateTime(year, range.item1, 1);
									end = DateTime(year, range.item2, DateTime(year, range.item2 + 1, 0).day, 23, 59, 59);
									break;
								case 'Month':
									final year = _selectedMonthYear ?? DateTime.now().year;
									start = DateTime(year, _selectedMonth, 1);
									end = DateTime(year, _selectedMonth, DateTime(year, _selectedMonth + 1, 0).day, 23, 59, 59);
									break;
								case 'Custom':
									start = _customRange?.start;
									end = _customRange?.end;
									break;
							}

							bool inRange(DateTime date) {
								if (start != null && date.isBefore(start!)) return false;
								if (end != null && date.isAfter(end!)) return false;
								return true;
							}

							final filteredGoals = goals.where((g) => inRange(g.createdAt)).toList();
							final filteredCompletedGoals = goals
									.where((g) => g.completedAt != null && inRange(g.completedAt!))
									.toList();
							final filteredAchievements = achievements.where((a) => inRange(a.date)).toList();

							final goalCompletionRate = filteredGoals.isEmpty
									? 0.0
									: filteredCompletedGoals.length / filteredGoals.length;

							final rangeStart = start ?? _rangeStart(goals, achievements) ?? DateTime.now();
							final rangeEnd = end ?? _rangeEnd(goals, achievements) ?? DateTime.now();
							final monthsSpan = ((rangeEnd.year - rangeStart.year) * 12 + (rangeEnd.month - rangeStart.month) + 1).clamp(1, 1200);
							final avgGoalsCreated = filteredGoals.length / monthsSpan;
							final avgGoalsCompleted = filteredCompletedGoals.length / monthsSpan;

							final goalsByCategory = <String, int>{
								for (final c in _goalCategories) c: 0,
							};
							for (final g in filteredGoals) {
								goalsByCategory[g.category] = (goalsByCategory[g.category] ?? 0) + 1;
							}

							final achievementsByCategory = <String, int>{
								for (final c in _goalCategories) c: 0,
							};
							for (final a in filteredAchievements) {
								achievementsByCategory[a.category] = (achievementsByCategory[a.category] ?? 0) + 1;
							}

							final startedPerMonth = List<int>.filled(12, 0);
							final completedPerMonth = List<int>.filled(12, 0);
							for (final g in filteredGoals) {
								startedPerMonth[g.createdAt.month - 1] += 1;
							}
							for (final g in filteredCompletedGoals) {
								final date = g.completedAt ?? g.endDate ?? g.createdAt;
								completedPerMonth[date.month - 1] += 1;
							}

							final categoryPerformance = <String, double>{
								for (final c in _goalCategories) c: 0,
							};
							for (final c in _goalCategories) {
								final total = filteredGoals.where((g) => g.category == c).length;
								final completed = filteredCompletedGoals.where((g) => g.category == c).length;
								categoryPerformance[c] = total == 0 ? 0 : completed / total;
							}

							return SingleChildScrollView(
								padding: const EdgeInsets.all(16),
								child: Column(
									crossAxisAlignment: CrossAxisAlignment.start,
									children: [
										_buildFilterRow(years),
										const SizedBox(height: 16),
										Wrap(
											spacing: 16,
											runSpacing: 16,
											children: [
												_buildSummaryCard('Totals', '${filteredGoals.length} goals\n${filteredAchievements.length} achievements'),
												_buildSummaryCard('Avg goals created', avgGoalsCreated.toStringAsFixed(2)),
												_buildSummaryCard('Avg goals completed', avgGoalsCompleted.toStringAsFixed(2)),
												_buildSummaryCard('Completion rate', '${(goalCompletionRate * 100).toStringAsFixed(1)}%'),
											],
										),
										const SizedBox(height: 24),
										_buildCard(
											child: Column(
												crossAxisAlignment: CrossAxisAlignment.start,
												children: [
													const Text('Goal distribution by category', style: TextStyle(fontWeight: FontWeight.w600)),
													const SizedBox(height: 12),
													SizedBox(
														height: 220,
														child: PieChart(PieChartData(
															sections: goalsByCategory.entries
																	.where((e) => e.value > 0)
																	.map((e) => PieChartSectionData(
																title: '${e.key}\n${e.value}',
																value: e.value.toDouble(),
																color: _pastelColorFor(e.key),
																radius: 70,
																titleStyle: const TextStyle(fontSize: 12, color: Colors.white, fontWeight: FontWeight.w600),
															))
																	.toList(),
															sectionsSpace: 4,
															centerSpaceRadius: 30,
														)),
													),
												],
											),
										),
										const SizedBox(height: 16),
										_buildCard(
											child: Column(
												crossAxisAlignment: CrossAxisAlignment.start,
												children: [
													const Text('Achievements by category', style: TextStyle(fontWeight: FontWeight.w600)),
													const SizedBox(height: 12),
													SizedBox(
														height: 220,
														child: PieChart(PieChartData(
															sections: achievementsByCategory.entries
																	.where((e) => e.value > 0)
																	.map((e) => PieChartSectionData(
																title: '${e.key}\n${e.value}',
																value: e.value.toDouble(),
																color: _pastelColorFor(e.key).withOpacity(0.8),
																radius: 70,
																titleStyle: const TextStyle(fontSize: 12, color: Colors.white, fontWeight: FontWeight.w600),
															))
																	.toList(),
															sectionsSpace: 4,
															centerSpaceRadius: 30,
														)),
													),
												],
											),
										),
										const SizedBox(height: 16),
										_buildCard(
											child: Column(
												crossAxisAlignment: CrossAxisAlignment.start,
												children: [
													const Text('Goals started vs completed by month', style: TextStyle(fontWeight: FontWeight.w600)),
													const SizedBox(height: 12),
													SizedBox(
														height: 260,
														child: BarChart(BarChartData(
															barGroups: List.generate(12, (i) => BarChartGroupData(
																x: i,
																barRods: [
																	BarChartRodData(toY: startedPerMonth[i].toDouble(), color: const Color(0xFF7FB3D5), width: 10),
																	BarChartRodData(toY: completedPerMonth[i].toDouble(), color: const Color(0xFF76D7C4), width: 10),
																],
															)),
															titlesData: FlTitlesData(
																bottomTitles: AxisTitles(
																	sideTitles: SideTitles(
																		showTitles: true,
																		getTitlesWidget: (value, meta) {
																			final month = DateFormat.MMM().format(DateTime(0, value.toInt() + 1));
																			return Padding(
																				padding: const EdgeInsets.only(top: 8.0),
																				child: Text(month, style: const TextStyle(fontSize: 10)),
																			);
																		},
																	),
																),
																leftTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
																rightTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
																topTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
															),
															gridData: const FlGridData(show: false),
															borderData: FlBorderData(show: false),
														)),
													),
												],
											),
										),
										const SizedBox(height: 16),
										_buildCard(
											child: Column(
												crossAxisAlignment: CrossAxisAlignment.start,
												children: [
													const Text('Category performance radar', style: TextStyle(fontWeight: FontWeight.w600)),
													const SizedBox(height: 12),
													SizedBox(
														height: 260,
														child: RadarChart(RadarChartData(
															dataSets: [
																RadarDataSet(
																	fillColor: const Color(0xFF76D7C4).withOpacity(0.4),
																	borderColor: const Color(0xFF76D7C4),
																	entryRadius: 2,
																	dataEntries: categoryPerformance.values.map((v) => RadarEntry(value: v)).toList(),
																),
															],
															radarBackgroundColor: Colors.white,
															gridBorderData: BorderSide(color: Colors.grey.withOpacity(0.3)),
															tickCount: 4,
															radarShape: RadarShape.polygon,
															//getTitle: (index) => '',
														)),
													),
													const SizedBox(height: 8),
													Wrap(
														spacing: 8,
														runSpacing: 4,
														children: categoryPerformance.keys.map((k) => Chip(label: Text(k))).toList(),
													),
												],
											),
										),
									],
								),
							);
						},
					);
				},
			),
		);
	}

	Widget _buildFilterRow(List<int> years) {
		return _buildCard(
			child: Column(
				crossAxisAlignment: CrossAxisAlignment.start,
				children: [
					Row(
						children: [
							const Text('Filter: ', style: TextStyle(fontWeight: FontWeight.w600)),
							const SizedBox(width: 12),
							DropdownButton<String>(
								value: _mode,
								items: const [
									DropdownMenuItem(value: 'All Time', child: Text('All Time')),
									DropdownMenuItem(value: 'Year', child: Text('Year')),
									DropdownMenuItem(value: 'Quarter', child: Text('Quarter')),
									DropdownMenuItem(value: 'Month', child: Text('Month')),
									DropdownMenuItem(value: 'Custom', child: Text('Custom Range')),
								],
								onChanged: (value) {
									if (value != null) _setMode(value, years);
								},
							),
						],
					),
					if (_mode == 'Year') ...[
						const SizedBox(height: 12),
						DropdownButton<int>(
							value: _selectedYear,
							items: years.map((y) => DropdownMenuItem(value: y, child: Text('$y'))).toList(),
							onChanged: (v) => setState(() => _selectedYear = v),
						),
					],
					if (_mode == 'Quarter') ...[
						const SizedBox(height: 12),
						Row(
							children: [
								DropdownButton<int>(
									value: _selectedQuarterYear,
									items: years.map((y) => DropdownMenuItem(value: y, child: Text('$y'))).toList(),
									onChanged: (v) => setState(() => _selectedQuarterYear = v),
								),
								const SizedBox(width: 12),
								DropdownButton<String>(
									value: _selectedQuarter,
									items: const [
										DropdownMenuItem(value: 'Q1', child: Text('Q1')),
										DropdownMenuItem(value: 'Q2', child: Text('Q2')),
										DropdownMenuItem(value: 'Q3', child: Text('Q3')),
										DropdownMenuItem(value: 'Q4', child: Text('Q4')),
									],
									onChanged: (v) => setState(() => _selectedQuarter = v ?? 'Q1'),
								),
							],
						),
					],
					if (_mode == 'Month') ...[
						const SizedBox(height: 12),
						Row(
							children: [
								DropdownButton<int>(
									value: _selectedMonthYear,
									items: years.map((y) => DropdownMenuItem(value: y, child: Text('$y'))).toList(),
									onChanged: (v) => setState(() => _selectedMonthYear = v),
								),
								const SizedBox(width: 12),
								DropdownButton<int>(
									value: _selectedMonth,
									items: List.generate(12, (index) => index + 1)
											.map((m) => DropdownMenuItem(value: m, child: Text(DateFormat.MMMM().format(DateTime(0, m)))))
											.toList(),
									onChanged: (v) => setState(() => _selectedMonth = v ?? DateTime.now().month),
								),
							],
						),
					],
					if (_mode == 'Custom') ...[
						const SizedBox(height: 12),
						TextButton.icon(
							onPressed: () async {
								final picker = await showDateRangePicker(
									context: context,
									firstDate: DateTime(2000),
									lastDate: DateTime(2100),
									initialDateRange: _customRange,
								);
								if (picker != null) {
									setState(() => _customRange = picker);
								}
							},
							icon: const Icon(Icons.date_range),
							label: Text(_customRange == null
									? 'Select range'
									: '${DateFormat.yMMMd().format(_customRange!.start)} → ${DateFormat.yMMMd().format(_customRange!.end)}'),
						),
					],
				],
			),
		);
	}

	Widget _buildSummaryCard(String title, String value) {
		return _buildCard(
			width: 160,
			child: Column(
				crossAxisAlignment: CrossAxisAlignment.start,
				children: [
					Text(title, style: const TextStyle(fontWeight: FontWeight.w600, color: AppColors.textSecondary)),
					const SizedBox(height: 8),
					Text(value, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
				],
			),
		);
	}

	Widget _buildCard({required Widget child, double? width}) {
		return Container(
			width: width,
			decoration: BoxDecoration(
				color: Colors.white,
				borderRadius: BorderRadius.circular(20),
				boxShadow: [
					BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 12, offset: const Offset(0, 6)),
				],
			),
			padding: const EdgeInsets.all(16),
			child: child,
		);
	}
}

Color _pastelColorFor(String category) {
	switch (category) {
		case 'Health & Wellness':
			return const Color(0xFF89CFF0);
		case 'Career & Finance':
			return const Color(0xFF9FD8CB);
		case 'Education & Learning':
			return const Color(0xFFF4B183);
		case 'Relationships & Community':
			return const Color(0xFFE6B0AA);
		case 'Personal Growth':
			return const Color(0xFFD2B4DE);
		default:
			return const Color(0xFFB0BEC5);
	}
}

class Tuple2<T1, T2> {
	final T1 item1;
	final T2 item2;
	const Tuple2(this.item1, this.item2);
}


