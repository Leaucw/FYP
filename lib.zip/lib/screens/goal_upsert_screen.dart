import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:uuid/uuid.dart';
import '../models/goal.dart';
import '../services/goal_service.dart';
import '../theme/app_colors.dart';
import 'location_picker_screen.dart';

const _goalCategories = [
	'Health & Wellness',
	'Career & Finance',
	'Education & Learning',
	'Relationships & Community',
	'Personal Growth',
];

class _SubGoalDraft {
	final String id;
	final TextEditingController controller;
	bool completed;

	_SubGoalDraft({
		required this.id,
		required String initialTitle,
		required this.completed,
	}) : controller = TextEditingController(text: initialTitle);
}

class GoalUpsertScreen extends StatefulWidget {
	final Goal? existing;
	const GoalUpsertScreen.create({super.key}) : existing = null;
	const GoalUpsertScreen.edit({super.key, required this.existing});

	@override
	State<GoalUpsertScreen> createState() => _GoalUpsertScreenState();
}

class _GoalUpsertScreenState extends State<GoalUpsertScreen> {
	final _formKey = GlobalKey<FormState>();
	final _titleCtrl = TextEditingController();
	final _descCtrl = TextEditingController();
	final _locationCtrl = TextEditingController();
	final List<String> _people = [];
	DateTime? _startDate;
	DateTime? _endDate;
	String? _selectedCategory = _goalCategories.first;
	double? _lat;
	double? _lng;
	final List<_SubGoalDraft> _subGoals = [];

	final _auth = FirebaseAuth.instance;
	final _service = GoalService(db: FirebaseFirestore.instance);

	@override
	void initState() {
		super.initState();
		final g = widget.existing;
		if (g != null) {
			_titleCtrl.text = g.title;
			_descCtrl.text = g.description;
			_people.addAll(g.associatedPeople);
			_locationCtrl.text = g.locationName ?? '';
			_startDate = g.startDate;
			_endDate = g.endDate;
			_selectedCategory = g.category;
			_lat = g.latitude;
			_lng = g.longitude;
			for (final s in g.subGoals) {
				_subGoals.add(_SubGoalDraft(
					id: s.id,
					initialTitle: s.title,
					completed: s.completed,
				));
			}
		}
		if (_subGoals.isEmpty) {
			_subGoals.add(_SubGoalDraft(
				id: const Uuid().v4(),
				initialTitle: '',
				completed: false,
			));
		}
	}

	@override
	void dispose() {
		_titleCtrl.dispose();
		_descCtrl.dispose();
		_locationCtrl.dispose();
		for (final s in _subGoals) {
			s.controller.dispose();
		}
		super.dispose();
	}

	Future<void> _pickDate({required bool start}) async {
		final initial = start ? (_startDate ?? DateTime.now()) : (_endDate ?? DateTime.now());
		final picked = await showDatePicker(
			context: context,
			initialDate: initial,
			firstDate: DateTime(2000),
			lastDate: DateTime(2100),
		);
		if (picked != null) {
			setState(() {
				if (start) {
					_startDate = picked;
				} else {
					_endDate = picked;
				}
			});
		}
	}

	void _addSubGoalField() {
		setState(() {
			_subGoals.add(_SubGoalDraft(
				id: const Uuid().v4(),
				initialTitle: '',
				completed: false,
			));
		});
	}

	void _removeSubGoalField(_SubGoalDraft draft) {
		if (_subGoals.length == 1) return;
		setState(() {
			draft.controller.dispose();
			_subGoals.remove(draft);
		});
	}

	Future<void> _pickLocation() async {
		final result = await Navigator.push<LocationResult>(
			context,
			MaterialPageRoute(
				builder: (_) => LocationPickerScreen(
					initialLat: _lat,
					initialLng: _lng,
					initialName: _locationCtrl.text.isEmpty ? null : _locationCtrl.text,
				),
			),
		);
		if (result != null) {
			setState(() {
				_lat = result.latitude;
				_lng = result.longitude;
				if (result.name != null) {
					_locationCtrl.text = result.name!;
				}
			});
		}
	}

	Future<void> _addPerson() async {
		final ctrl = TextEditingController();
		final added = await showDialog<String>(
			context: context,
			builder: (_) => AlertDialog(
				title: const Text('Add person'),
				content: TextField(controller: ctrl, decoration: const InputDecoration(hintText: 'Name')),
				actions: [
					TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
					TextButton(onPressed: () => Navigator.pop(context, ctrl.text.trim()), child: const Text('Add')),
				],
			),
		);
		if (added != null && added.isNotEmpty) {
			setState(() => _people.add(added));
		}
	}

	Future<void> _save() async {
		if (!_formKey.currentState!.validate()) return;
		final user = _auth.currentUser;
		if (user == null) return;
		final now = DateTime.now();
		final subGoals = _subGoals
				.where((s) => s.controller.text.trim().isNotEmpty)
				.map((s) => SubGoal(
			id: s.id,
			title: s.controller.text.trim(),
			completed: s.completed,
			dueDate: null,
		))
				.toList();
		final goal = Goal(
			id: widget.existing?.id ?? '',
			userId: user.uid,
			title: _titleCtrl.text.trim(),
			description: _descCtrl.text.trim(),
			category: _selectedCategory ?? _goalCategories.first,
			startDate: _startDate,
			endDate: _endDate,
			completedAt: widget.existing?.completedAt,
			locationName: _locationCtrl.text.isEmpty ? null : _locationCtrl.text,
			latitude: _lat,
			longitude: _lng,
			associatedPeople: _people,
			status: widget.existing?.status ?? GoalStatus.inProgress,
			subGoals: subGoals,
			convertedToAchievement: widget.existing?.convertedToAchievement ?? false,
			createdAt: widget.existing?.createdAt ?? now,
			updatedAt: now,
		);
		if (widget.existing == null) {
			await _service.createGoal(user.uid, goal);
		} else {
			await _service.updateGoal(user.uid, goal);
		}
		if (mounted) Navigator.pop(context);
	}

	@override
	Widget build(BuildContext context) {
		return Scaffold(
			appBar: AppBar(
				title: Text(widget.existing == null ? 'Create Goal' : 'Edit Goal'),
				backgroundColor: AppColors.primary,
				foregroundColor: Colors.white,
				actions: [
					if (widget.existing != null)
						IconButton(
							icon: const Icon(Icons.delete),
							onPressed: () async {
								final confirm = await showDialog<bool>(
									context: context,
									builder: (_) => AlertDialog(
										title: const Text('Delete goal?'),
										content: const Text('This action cannot be undone.'),
										actions: [
											TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')),
											TextButton(onPressed: () => Navigator.pop(context, true), child: const Text('Delete')),
										],
									),
								) ??
										false;
								if (!confirm) return;
								final user = _auth.currentUser;
								if (user == null) return;
								await _service.deleteGoal(user.uid, widget.existing!.id);
								if (mounted) Navigator.pop(context);
							},
						),
				],
			),
			body: Form(
				key: _formKey,
				child: ListView(
					padding: const EdgeInsets.all(16),
					children: [
						TextFormField(
							controller: _titleCtrl,
							decoration: const InputDecoration(labelText: 'Title'),
							validator: (v) => (v == null || v.trim().isEmpty) ? 'Required' : null,
						),
						const SizedBox(height: 12),
						TextFormField(
							controller: _descCtrl,
							maxLines: 3,
							decoration: const InputDecoration(labelText: 'Description'),
						),
						const SizedBox(height: 12),
						DropdownButtonFormField<String>(
							value: _selectedCategory,
							items: _goalCategories.map((c) => DropdownMenuItem(value: c, child: Text(c))).toList(),
							onChanged: (value) => setState(() => _selectedCategory = value),
							decoration: const InputDecoration(labelText: 'Category'),
						),
						const SizedBox(height: 12),
						TextFormField(
							controller: _locationCtrl,
							readOnly: true,
							decoration: const InputDecoration(labelText: 'Location (from map)', suffixIcon: Icon(Icons.lock)),
						),
						const SizedBox(height: 8),
						Row(
							children: [
								ElevatedButton.icon(
									onPressed: _pickLocation,
									icon: const Icon(Icons.map),
									label: const Text('Select on map'),
								),
								const SizedBox(width: 12),
								if (_lat != null && _lng != null) Text('(${_lat!.toStringAsFixed(3)}, ${_lng!.toStringAsFixed(3)})'),
							],
						),
						const SizedBox(height: 12),
						Row(
							children: [
								Expanded(
									child: TextButton.icon(
										onPressed: () => _pickDate(start: true),
										icon: const Icon(Icons.date_range),
										label: Text(_startDate == null ? 'Start date' : _startDate!.toIso8601String().split('T').first),
									),
								),
								const SizedBox(width: 12),
								Expanded(
									child: TextButton.icon(
										onPressed: () => _pickDate(start: false),
										icon: const Icon(Icons.event),
										label: Text(_endDate == null ? 'End date' : _endDate!.toIso8601String().split('T').first),
									),
								),
							],
						),
						const SizedBox(height: 12),
						const Text('Associated people'),
						const SizedBox(height: 8),
						Wrap(
							spacing: 6,
							runSpacing: 6,
							children: [
								..._people.map((p) => Chip(
									label: Text(p),
									onDeleted: () => setState(() => _people.remove(p)),
								)),
								ActionChip(
									avatar: const Icon(Icons.add, size: 18),
									label: const Text('Add'),
									onPressed: _addPerson,
								),
							],
						),
						const SizedBox(height: 20),
						const Text('Sub-goals', style: TextStyle(fontWeight: FontWeight.w600)),
						const SizedBox(height: 8),
						Column(
							children: _subGoals.map((draft) {
								return Padding(
									padding: const EdgeInsets.symmetric(vertical: 4.0),
									child: Row(
										crossAxisAlignment: CrossAxisAlignment.center,
										children: [
											Checkbox(
												value: draft.completed,
												onChanged: (v) => setState(() => draft.completed = v ?? false),
											),
											Expanded(
												child: TextFormField(
													controller: draft.controller,
													decoration: const InputDecoration(
														labelText: 'Sub-goal title',
													),
												),
											),
											IconButton(
												icon: const Icon(Icons.remove_circle_outline),
												onPressed: () => _removeSubGoalField(draft),
											),
										],
									),
								);
							}).toList(),
						),
						TextButton.icon(
							onPressed: _addSubGoalField,
							icon: const Icon(Icons.add),
							label: const Text('Add sub-goal'),
						),
						const SizedBox(height: 24),
						ElevatedButton.icon(
							onPressed: _save,
							icon: const Icon(Icons.save),
							label: const Text('Save'),
						),
					],
				),
			),
		);
	}
}


