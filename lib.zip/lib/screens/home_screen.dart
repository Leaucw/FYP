import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../theme/app_colors.dart';
import 'achievements_list_screen.dart';
import 'profile_screen.dart';
import 'goals_list_screen.dart';
import 'timeline_screen.dart';
import 'analytics_dashboard_screen.dart';
import 'life_map_screen.dart';
import 'login_screen.dart';

// ⭐ NEW IMPORT
import 'connections_screen.dart';
import 'journal_list_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen>
    with SingleTickerProviderStateMixin {
  final User? user = FirebaseAuth.instance.currentUser;
  final _firestore = FirebaseFirestore.instance;

  Map<String, dynamic>? _userData;
  bool _isLoading = true;
  int _selectedIndex = 0;

  late AnimationController _controller;
  late Animation<double> _fadeAnimation;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 900));
    _fadeAnimation =
        CurvedAnimation(parent: _controller, curve: Curves.easeInOut);
    _loadUserData();
  }

  Future<void> _loadUserData() async {
    if (user == null) return;
    try {
      final doc = await _firestore.collection('users').doc(user!.uid).get();
      if (doc.exists) _userData = doc.data();
    } catch (e) {
      debugPrint('❌ Error loading user data: $e');
    }
    setState(() => _isLoading = false);
    _controller.forward();
  }

  void _logout() async {
    await FirebaseAuth.instance.signOut();
    if (mounted) {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (_) => const LoginScreen()),
      );
    }
  }

  String _greeting() {
    final hour = DateTime.now().hour;
    if (hour < 12) return "Good Morning";
    if (hour < 17) return "Good Afternoon";
    return "Good Evening";
  }

  @override
  Widget build(BuildContext context) {
    final name = _userData?['name'] ?? user?.displayName ?? "User";
    final email = _userData?['email'] ?? user?.email ?? "";
    final photoBase64 = _userData?['photoBase64'];

    return Scaffold(
      backgroundColor: AppColors.background,
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 18),
          child: FadeTransition(
            opacity: _fadeAnimation,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // 🟦 Header
                AnimatedSlide(
                  duration: const Duration(milliseconds: 500),
                  offset: const Offset(0, -0.1),
                  curve: Curves.easeOut,
                  child: AnimatedOpacity(
                    duration: const Duration(milliseconds: 700),
                    opacity: 1.0,
                    child: Container(
                      decoration: BoxDecoration(
                        color: AppColors.primary,
                        borderRadius: BorderRadius.circular(22),
                      ),
                      padding: const EdgeInsets.all(20),
                      child: Row(
                        children: [
                          Container(
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              gradient: LinearGradient(
                                colors: [
                                  AppColors.highlight,
                                  AppColors.tertiary
                                ],
                              ),
                            ),
                            padding: const EdgeInsets.all(3.5),
                            child: CircleAvatar(
                              radius: 34,
                              backgroundColor: Colors.white,
                              backgroundImage: (photoBase64 != null &&
                                  photoBase64.isNotEmpty)
                                  ? MemoryImage(base64Decode(photoBase64))
                                  : const AssetImage(
                                  'assets/images/default_user.png')
                              as ImageProvider,
                            ),
                          ),
                          const SizedBox(width: 16),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  "${_greeting()},",
                                  style: const TextStyle(
                                    color: Colors.white70,
                                    fontSize: 15,
                                  ),
                                ),
                                Text(
                                  name,
                                  style: const TextStyle(
                                    color: Colors.white,
                                    fontSize: 22,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                const SizedBox(height: 4),
                                Text(
                                  email,
                                  style: const TextStyle(
                                    color: Color(0xFFBAE8E8),
                                    fontSize: 13,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          IconButton(
                            onPressed: _logout,
                            icon: const Icon(Icons.logout,
                                color: Colors.white),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),

                const SizedBox(height: 25),

                // 🟨 Quote Card
                AnimatedOpacity(
                  duration: const Duration(milliseconds: 800),
                  opacity: 1.0,
                  child: AnimatedScale(
                    scale: 1.0,
                    duration: const Duration(milliseconds: 600),
                    curve: Curves.easeOutBack,
                    child: Container(
                      width: double.infinity,
                      decoration: BoxDecoration(
                        color: AppColors.secondary,
                        borderRadius: BorderRadius.circular(18),
                      ),
                      padding: const EdgeInsets.all(18),
                      child: const Text(
                        "“Track your growth, feel your emotions, and value your connections.”",
                        style: TextStyle(
                          fontSize: 15,
                          color: AppColors.textSecondary,
                          fontStyle: FontStyle.italic,
                        ),
                      ),
                    ),
                  ),
                ),

                const SizedBox(height: 25),

                // 🧩 Feature Cards
                _animatedFeatureCard(
                  delay: 100,
                  title: "Goals",
                  subtitle:
                  "Define goals, sub-goals, track progress and convert to achievements.",
                  icon: Icons.flag_rounded,
                  color: Colors.indigo.shade400,
                ),

                _animatedFeatureCard(
                  delay: 180,
                  title: "Achievements",
                  subtitle:
                  "Celebrate your milestones and reflect on personal growth.",
                  icon: Icons.emoji_events_rounded,
                  color: Colors.green.shade400,
                ),

                _animatedFeatureCard(
                  delay: 250,
                  title: "Life Timeline",
                  subtitle:
                  "Organize milestones into life stages chronologically.",
                  icon: Icons.timeline_rounded,
                  color: Colors.teal.shade400,
                ),

                _animatedFeatureCard(
                  delay: 400,
                  title: "Analytics & Dashboard",
                  subtitle:
                  "Completion rates, distributions, MBTI insights and recommendations.",
                  icon: Icons.analytics_rounded,
                  color: Colors.purple.shade400,
                ),

                _animatedFeatureCard(
                  delay: 550,
                  title: "Life Map",
                  subtitle:
                  "Plot achievements and goals on an interactive map.",
                  icon: Icons.map_rounded,
                  color: Colors.orange.shade500,
                ),

                // ⭐ NEW MODULE ADDED HERE
                _animatedFeatureCard(
                  delay: 650,
                  title: "Connections",
                  subtitle:
                  "Manage your relationships and people in your life.",
                  icon: Icons.groups_rounded,
                  color: Colors.pinkAccent,
                ),

                _animatedFeatureCard(
                  delay: 720,
                  title: "Journal & Reflection",
                  subtitle: "Write daily reflections and track your thoughts.",
                  icon: Icons.book_rounded,
                  color: Colors.blueAccent,
                ),


                const SizedBox(height: 80),
              ],
            ),
          ),
        ),
      ),

      floatingActionButton: FloatingActionButton(
        onPressed: () {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text("Feature coming soon 🚀")),
          );
        },
        backgroundColor: AppColors.highlight,
        child: const Icon(Icons.add, color: AppColors.textButton),
      ),

      bottomNavigationBar: Container(
        color: Colors.white,
        padding: const EdgeInsets.symmetric(vertical: 8),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            _buildMinimalNavItem(Icons.home_rounded, "Home", 0),
            _buildMinimalNavItem(Icons.person_rounded, "Profile", 1),
            _buildMinimalNavItem(Icons.settings_rounded, "Settings", 2),
          ],
        ),
      ),
    );
  }

  // 🔹 Nav Item
  Widget _buildMinimalNavItem(IconData icon, String label, int index) {
    final bool isSelected = _selectedIndex == index;
    const animDuration = Duration(milliseconds: 250);

    return GestureDetector(
      onTap: () {
        setState(() => _selectedIndex = index);
        if (index == 1 && user != null) {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => ProfileScreen(user: user!)),
          ).then((_) => _loadUserData());
        }
      },
      child: AnimatedContainer(
        duration: animDuration,
        curve: Curves.easeOut,
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            AnimatedScale(
              duration: animDuration,
              scale: isSelected ? 1.2 : 1.0,
              child: Icon(
                icon,
                size: 26,
                color:
                isSelected ? AppColors.primary : Colors.grey.shade500,
              ),
            ),
            const SizedBox(height: 4),
            AnimatedDefaultTextStyle(
              duration: animDuration,
              style: TextStyle(
                fontSize: isSelected ? 13 : 12,
                fontWeight:
                isSelected ? FontWeight.w700 : FontWeight.w500,
                color:
                isSelected ? AppColors.primary : Colors.grey.shade500,
              ),
              child: Text(label),
            ),
          ],
        ),
      ),
    );
  }

  // Animation Wrapper
  Widget _animatedFeatureCard({
    required int delay,
    required String title,
    required String subtitle,
    required IconData icon,
    required Color color,
  }) {
    return TweenAnimationBuilder<double>(
      duration: Duration(milliseconds: 600 + delay),
      tween: Tween(begin: 0, end: 1),
      curve: Curves.easeOutCubic,
      builder: (context, value, child) => Transform.translate(
        offset: Offset(0, 30 * (1 - value)),
        child: Opacity(opacity: value, child: child),
      ),
      child: _buildFeatureCard(
        title: title,
        subtitle: subtitle,
        icon: icon,
        color: color,
      ),
    );
  }

  // Card Builder
  Widget _buildFeatureCard({
    required String title,
    required String subtitle,
    required IconData icon,
    required Color color,
  }) {
    return Container(
      margin: const EdgeInsets.only(bottom: 18),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 12,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
        leading: Container(
          decoration: BoxDecoration(
            color: color.withOpacity(0.15),
            borderRadius: BorderRadius.circular(14),
          ),
          padding: const EdgeInsets.all(10),
          child: Icon(icon, color: color, size: 30),
        ),
        title: Text(
          title,
          style: const TextStyle(
            color: AppColors.textPrimary,
            fontSize: 17,
            fontWeight: FontWeight.bold,
          ),
        ),
        subtitle: Text(
          subtitle,
          style: const TextStyle(
            color: AppColors.textSecondary,
            fontSize: 13.5,
          ),
        ),
        trailing: const Icon(Icons.arrow_forward_ios_rounded,
            color: Colors.grey, size: 16),
        onTap: () {

          if (title == "Goals") {
            Navigator.push(context,
                MaterialPageRoute(builder: (_) => GoalsListScreen()));
            return;
          }

          if (title == "Achievements") {
            Navigator.push(context,
                MaterialPageRoute(builder: (_) => AchievementsListScreen()));
            return;
          }

          if (title == "Life Timeline") {
            Navigator.push(context,
                MaterialPageRoute(builder: (_) => TimelineScreen()));
            return;
          }

          if (title == "Analytics & Dashboard") {
            Navigator.push(context,
                MaterialPageRoute(builder: (_) => AnalyticsDashboardScreen()));
            return;
          }

          if (title == "Life Map") {
            Navigator.push(
                context, MaterialPageRoute(builder: (_) => LifeMapScreen()));
            return;
          }

          // ⭐ NEW NAVIGATION
          if (title == "Connections") {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => ConnectionsScreen()),
            );
            return;
          }

          if (title == "Journal & Reflection") {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const JournalListScreen()),
            );
            return;
          }


          ScaffoldMessenger.of(context).showSnackBar(SnackBar(
            content: Text("$title module coming soon!"),
            backgroundColor: color.withOpacity(0.9),
          ));
        },
      ),
    );
  }
}
