import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:intl/intl.dart';
import '../models/life_stage.dart';
import '../models/goal.dart';
import '../models/achievement.dart';
import '../services/life_stage_service.dart';
import '../services/goal_service.dart';
import '../services/achievement_service.dart';
import '../theme/app_colors.dart';

class TimelineScreen extends StatelessWidget {
	final _auth = FirebaseAuth.instance;
	final _stages = LifeStageService(db: FirebaseFirestore.instance);
	final _goals = GoalService(db: FirebaseFirestore.instance);
	final _achievements = AchievementService(db: FirebaseFirestore.instance);

	TimelineScreen({super.key});

	Future<void> _showColorPicker(BuildContext context, Color initialColor, Function(Color) onColorSelected) async {
		Color selectedColor = initialColor;
		await showDialog(
			context: context,
			builder: (context) => StatefulBuilder(
				builder: (context, setState) => AlertDialog(
					title: const Text('Pick a color'),
					content: SizedBox(
						width: 300,
						height: 400,
						child: ColorPickerWidget(
							initialColor: initialColor,
							onColorChanged: (color) {
								setState(() => selectedColor = color);
							},
						),
					),
					actions: [
						TextButton(
							onPressed: () => Navigator.pop(context),
							child: const Text('Cancel'),
						),
						TextButton(
							onPressed: () {
								onColorSelected(selectedColor);
								Navigator.pop(context);
							},
							child: const Text('Select'),
						),
					],
				),
			),
		);
	}

	Future<void> _showAddEditDialog(BuildContext context, {LifeStage? existing}) async {
		final nameCtrl = TextEditingController(text: existing?.name ?? '');
		DateTime? startDate = existing?.startDate;
		DateTime? endDate = existing?.endDate;
		Color selectedColor = existing != null ? Color(existing.colorValue) : Colors.blue.shade400;

		await showDialog(
			context: context,
			builder: (_) => StatefulBuilder(
				builder: (context, setModalState) => AlertDialog(
					title: Text(existing == null ? 'Add life stage' : 'Edit life stage'),
					content: SingleChildScrollView(
						child: Column(
							mainAxisSize: MainAxisSize.min,
							children: [
								TextField(
									controller: nameCtrl,
									decoration: const InputDecoration(labelText: 'Name'),
								),
								const SizedBox(height: 16),
								Row(
									children: [
										Expanded(
											child: TextButton.icon(
												icon: const Icon(Icons.calendar_today),
												label: Text(startDate == null ? 'Start date' : DateFormat.yMMMMd().format(startDate!)),
												onPressed: () async {
													final picked = await showDatePicker(
														context: context,
														initialDate: startDate ?? DateTime(DateTime.now().year - 5),
														firstDate: DateTime(1900),
														lastDate: DateTime(2100),
													);
													if (picked != null) {
														setModalState(() => startDate = picked);
													}
												},
											),
										),
										const SizedBox(width: 8),
										Expanded(
											child: TextButton.icon(
												icon: const Icon(Icons.event),
												label: Text(endDate == null ? 'End date' : DateFormat.yMMMMd().format(endDate!)),
												onPressed: () async {
													final picked = await showDatePicker(
														context: context,
														initialDate: endDate ?? DateTime(DateTime.now().year),
														firstDate: DateTime(1900),
														lastDate: DateTime(2100),
													);
													if (picked != null) {
														setModalState(() => endDate = picked);
													}
												},
											),
										),
									],
								),
								const SizedBox(height: 16),
								Row(
									children: [
										const Text('Color: '),
										GestureDetector(
											onTap: () async {
												await _showColorPicker(context, selectedColor, (color) {
													setModalState(() => selectedColor = color);
												});
											},
											child: Container(
												width: 40,
												height: 40,
												decoration: BoxDecoration(
													color: selectedColor,
													shape: BoxShape.circle,
													border: Border.all(color: Colors.grey, width: 2),
												),
											),
										),
										const SizedBox(width: 8),
										TextButton(
											onPressed: () async {
												await _showColorPicker(context, selectedColor, (color) {
													setModalState(() => selectedColor = color);
												});
											},
											child: const Text('Pick color'),
										),
									],
								),
							],
						),
					),
					actions: [
						TextButton(
							onPressed: () => Navigator.pop(context),
							child: const Text('Cancel'),
						),
						if (existing != null)
							TextButton(
								onPressed: () async {
									await _stages.delete(_auth.currentUser!.uid, existing.id);
									if (context.mounted) Navigator.pop(context);
								},
								child: const Text('Delete', style: TextStyle(color: Colors.red)),
							),
						TextButton(
							onPressed: () async {
								final currentUser = _auth.currentUser;
								if (currentUser != null && nameCtrl.text.trim().isNotEmpty) {
									if (existing == null) {
										await _stages.create(currentUser.uid, LifeStage(
											id: '',
											userId: currentUser.uid,
											name: nameCtrl.text.trim(),
											startDate: startDate,
											endDate: endDate,
											sortOrder: DateTime.now().millisecondsSinceEpoch,
											colorValue: selectedColor.value,
										));
									} else {
										await _stages.update(currentUser.uid, LifeStage(
											id: existing.id,
											userId: existing.userId,
											name: nameCtrl.text.trim(),
											startDate: startDate,
											endDate: endDate,
											sortOrder: existing.sortOrder,
											colorValue: selectedColor.value,
										));
									}
								}
								if (context.mounted) Navigator.pop(context);
							},
							child: Text(existing == null ? 'Add' : 'Save'),
						),
					],
				),
			),
		);
	}

	@override
	Widget build(BuildContext context) {
		final user = _auth.currentUser;
		if (user == null) {
			return const Scaffold(body: Center(child: Text('Please sign in')));
		}
		return Scaffold(
			appBar: AppBar(
				title: const Text('Life Timeline'),
				backgroundColor: AppColors.primary,
				foregroundColor: Colors.white,
				actions: [
					IconButton(
						icon: const Icon(Icons.add),
						onPressed: () => _showAddEditDialog(context),
					),
				],
			),
			body: StreamBuilder<List<LifeStage>>(
				stream: _stages.stream(user.uid),
				builder: (context, stageSnap) {
					if (!stageSnap.hasData) return const Center(child: CircularProgressIndicator());
					return StreamBuilder<List<Goal>>(
						stream: _goals.streamGoals(user.uid),
						builder: (context, goalSnap) {
							if (!goalSnap.hasData) return const Center(child: CircularProgressIndicator());
							return StreamBuilder<List<Achievement>>(
								stream: _achievements.getAchievements(),
								builder: (context, achievementSnap) {
									if (!achievementSnap.hasData) return const Center(child: CircularProgressIndicator());

									final stages = stageSnap.data!..sort((a, b) {
										final aStart = a.startDate ?? DateTime.fromMillisecondsSinceEpoch(a.sortOrder);
										final bStart = b.startDate ?? DateTime.fromMillisecondsSinceEpoch(b.sortOrder);
										return aStart.compareTo(bStart);
									});

									final goals = goalSnap.data!;
									final achievements = achievementSnap.data!;
									final completedGoals = goals.where((g) => g.status == GoalStatus.completed).toList();

									if (stages.isEmpty) {
										return const Center(child: Text('Create your first life stage to build the timeline.'));
									}

									final assignedGoalIds = <String>{};
									final assignedAchievementIds = <String>{};
									final stageWidgets = <Widget>[];

									for (final stage in stages) {
										final baseColor = Color(stage.colorValue);
										final stageGoalEntries = completedGoals.where((g) {
											final date = g.completedAt ?? g.endDate ?? g.startDate ?? g.createdAt;
											if (stage.startDate != null && date.isBefore(stage.startDate!)) return false;
											if (stage.endDate != null && date.isAfter(stage.endDate!)) return false;
											return true;
										}).toList();
										assignedGoalIds.addAll(stageGoalEntries.map((g) => g.id));

										final stageAchievementEntries = achievements.where((a) {
											final date = a.date;
											if (a.lifeStageId != null) return a.lifeStageId == stage.id;
											if (stage.startDate != null && date.isBefore(stage.startDate!)) return false;
											if (stage.endDate != null && date.isAfter(stage.endDate!)) return false;
											return true;
										}).toList();
										assignedAchievementIds.addAll(stageAchievementEntries.map((a) => a.id));

										final entries = <_TimelineEntry>[
											...stageGoalEntries.map((g) => _TimelineEntry(
												date: g.completedAt ?? g.endDate ?? g.createdAt,
												title: g.title,
												subtitle: g.category,
												isAchievement: false,
											)),
											...stageAchievementEntries.map((a) => _TimelineEntry(
												date: a.date,
												title: a.title,
												subtitle: a.category,
												isAchievement: true,
											)),
										]
											..sort((a, b) => a.date.compareTo(b.date));

										stageWidgets.add(Container(
											margin: const EdgeInsets.only(bottom: 16),
											decoration: BoxDecoration(
												color: baseColor.withOpacity(0.18),
												borderRadius: BorderRadius.circular(16),
												border: Border(left: BorderSide(color: baseColor, width: 6)),
											),
											child: Padding(
												padding: const EdgeInsets.all(16),
												child: Column(
													crossAxisAlignment: CrossAxisAlignment.start,
													children: [
														Row(
															children: [
																Expanded(child: Text(stage.name, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w700))),
																IconButton(icon: const Icon(Icons.edit, size: 20), onPressed: () => _showAddEditDialog(context, existing: stage)),
															],
														),
														Text('${_formatStageDate(stage.startDate)} - ${_formatStageDate(stage.endDate)}', style: const TextStyle(color: AppColors.textSecondary)),
														const SizedBox(height: 12),
														if (entries.isEmpty)
															const Text('No items in this stage yet')
														else
															...entries.map((entry) => _timelineItem(
																color: baseColor,
																dateText: DateFormat.yMMMMd().format(entry.date),
																title: entry.title,
																subtitle: entry.subtitle,
																icon: Icon(entry.isAchievement ? Icons.emoji_events : Icons.flag, size: 14, color: Colors.white),
															)),
													],
												),
											),
										));
									}

									final unassignedGoals = completedGoals.where((g) => !assignedGoalIds.contains(g.id)).toList();
									final unassignedAchievements = achievements.where((a) => !assignedAchievementIds.contains(a.id)).toList();

									if (unassignedGoals.isNotEmpty || unassignedAchievements.isNotEmpty) {
										final entries = <_TimelineEntry>[
											...unassignedGoals.map((g) => _TimelineEntry(
												date: g.completedAt ?? g.endDate ?? g.createdAt,
												title: g.title,
												subtitle: g.category,
												isAchievement: false,
											)),
											...unassignedAchievements.map((a) => _TimelineEntry(
												date: a.date,
												title: a.title,
												subtitle: a.category,
												isAchievement: true,
											)),
										]
											..sort((a, b) => a.date.compareTo(b.date));

										stageWidgets.add(Container(
											padding: const EdgeInsets.all(16),
											decoration: BoxDecoration(
												color: Colors.grey.shade200,
												borderRadius: BorderRadius.circular(16),
											),
											child: Column(
												crossAxisAlignment: CrossAxisAlignment.start,
												children: [
													const Text('Unassigned items', style: TextStyle(fontWeight: FontWeight.bold)),
													const SizedBox(height: 8),
													...entries.map((entry) => _timelineItem(
														color: Colors.grey,
														dateText: DateFormat.yMMMMd().format(entry.date),
														title: entry.title,
														subtitle: entry.subtitle,
														icon: Icon(entry.isAchievement ? Icons.emoji_events : Icons.flag, size: 14, color: Colors.white),
													)),
												],
											),
										));
									}

									return ListView(
										padding: const EdgeInsets.all(16),
										children: stageWidgets,
									);
								},
							);
						},
					);
				},
			),
		);
	}
}

String _formatStageDate(DateTime? date) {
	if (date == null) return 'Present';
	return DateFormat.yMMMMd().format(date);
}

class _TimelineEntry {
	final DateTime date;
	final String title;
	final String subtitle;
	final bool isAchievement;

	_TimelineEntry({
		required this.date,
		required this.title,
		required this.subtitle,
		required this.isAchievement,
	});
}

Widget _timelineItem({
	required Color color,
	required String dateText,
	required String title,
	required String subtitle,
	required Widget icon,
}) {
	return Padding(
		padding: const EdgeInsets.symmetric(vertical: 8),
		child: Row(
			crossAxisAlignment: CrossAxisAlignment.start,
			children: [
				SizedBox(
					width: 90,
					child: Text(dateText, style: const TextStyle(fontSize: 12, color: AppColors.textSecondary)),
				),
				Column(
					children: [
						Stack(
							alignment: Alignment.center,
							children: [
								Container(width: 2, height: 44, color: color.withOpacity(0.6)),
								CircleAvatar(radius: 10, backgroundColor: color, child: icon),
							],
						),
					],
				),
				const SizedBox(width: 12),
				Expanded(
					child: Column(
						crossAxisAlignment: CrossAxisAlignment.start,
						children: [
							Text(title, style: const TextStyle(fontWeight: FontWeight.w700)),
							const SizedBox(height: 2),
							Text(subtitle, style: const TextStyle(fontSize: 12, color: AppColors.textSecondary)),
						],
					),
				),
			],
		),
	);
}

class ColorPickerWidget extends StatefulWidget {
	final Color initialColor;
	final Function(Color) onColorChanged;

	const ColorPickerWidget({
		super.key,
		required this.initialColor,
		required this.onColorChanged,
	});

	@override
	State<ColorPickerWidget> createState() => _ColorPickerWidgetState();
}

class _ColorPickerWidgetState extends State<ColorPickerWidget> {
	late HSVColor _hsvColor;

	@override
	void initState() {
		super.initState();
		_hsvColor = HSVColor.fromColor(widget.initialColor);
	}

	@override
	Widget build(BuildContext context) {
		return Column(
			children: [
				LayoutBuilder(
					builder: (context, constraints) {
						return GestureDetector(
							onPanUpdate: (details) {
								final localPos = details.localPosition;
								_updateColorFromPosition(localPos, constraints.maxWidth);
							},
							onTapDown: (details) {
								final localPos = details.localPosition;
								_updateColorFromPosition(localPos, constraints.maxWidth);
							},
							child: Container(
								width: double.infinity,
								height: 200,
								decoration: BoxDecoration(
									borderRadius: BorderRadius.circular(8),
									gradient: LinearGradient(
										begin: Alignment.topLeft,
										end: Alignment.bottomRight,
										colors: [
											_hsvColor.withSaturation(1.0).withValue(1.0).toColor(),
											_hsvColor.withSaturation(0.0).withValue(1.0).toColor(),
											_hsvColor.withSaturation(0.0).withValue(0.0).toColor(),
											_hsvColor.withSaturation(1.0).withValue(0.0).toColor(),
										],
									),
								),
							),
						);
					},
				),
				const SizedBox(height: 16),
				Row(
					children: [
						const Text('Hue: '),
						Expanded(
							child: Slider(
								value: _hsvColor.hue,
								min: 0,
								max: 360,
								divisions: 360,
								onChanged: (value) {
									setState(() {
										_hsvColor = _hsvColor.withHue(value);
										widget.onColorChanged(_hsvColor.toColor());
									});
								},
							),
						),
					],
				),
				Row(
					children: [
						const Text('Saturation: '),
						Expanded(
							child: Slider(
								value: _hsvColor.saturation,
								min: 0,
								max: 1,
								divisions: 100,
								onChanged: (value) {
									setState(() {
										_hsvColor = _hsvColor.withSaturation(value);
										widget.onColorChanged(_hsvColor.toColor());
									});
								},
							),
						),
					],
				),
				Row(
					children: [
						const Text('Value: '),
						Expanded(
							child: Slider(
								value: _hsvColor.value,
								min: 0,
								max: 1,
								divisions: 100,
								onChanged: (value) {
									setState(() {
										_hsvColor = _hsvColor.withValue(value);
										widget.onColorChanged(_hsvColor.toColor());
									});
								},
							),
						),
					],
				),
				const SizedBox(height: 16),
				Container(
					width: double.infinity,
					height: 50,
					decoration: BoxDecoration(
						color: _hsvColor.toColor(),
						borderRadius: BorderRadius.circular(8),
						border: Border.all(color: Colors.grey, width: 2),
					),
					child: Center(
						child: Text(
							'#${_hsvColor.toColor().value.toRadixString(16).substring(2).toUpperCase()}',
							style: TextStyle(
								color: _hsvColor.value > 0.5 ? Colors.black : Colors.white,
								fontWeight: FontWeight.bold,
							),
						),
					),
				),
			],
		);
	}

	void _updateColorFromPosition(Offset position, double width) {
		final height = 200.0;
		final x = position.dx.clamp(0, width);
		final y = position.dy.clamp(0, height);
		final saturation = (x / width).clamp(0.0, 1.0);
		final value = 1.0 - (y / height).clamp(0.0, 1.0);
		setState(() {
			_hsvColor = _hsvColor.withSaturation(saturation).withValue(value);
			widget.onColorChanged(_hsvColor.toColor());
		});
	}
}
